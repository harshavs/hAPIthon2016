﻿
/*
 * GET home page.
 */

exports.index = function (req, res) {
    res.render('index', { title: 'Express', year: new Date().getFullYear() });
};

exports.about = function (req, res) {
    res.render('about', { title: 'About', year: new Date().getFullYear(), message: 'Your application description page' });
};

exports.contact = function (req, res) {
    res.render('contact', { title: 'Contact', year: new Date().getFullYear(), message: 'Your contact page' });
};

exports.home= function (req, res) {
	//console.log(req);
	res.render('Home', { title: 'Home', year: new Date().getFullYear(), message: 'Your contact page' });
};

exports.home.post= function (req, res) {
	bookOrder();
	res.render('Home', { title: 'Home', year: new Date().getFullYear(), message: 'Your contact page' });
};

exports.book= function (req, res) {
    res.render('Home', { title: 'Home', year: new Date().getFullYear(), message: 'Your contact page' });
};

var tsURL = 'http://sbapi.onthedot.com:8282/api/v1.0/timeslots';
function bookOrder() {
	var querystring = require('querystring');
	var http = require('http');

	var addr = 'http://sbapi.onthedot.com:8282';

	var options = {
	    
		hostname: "sbapi.onthedot.com",
	    path: "/api/v1.0/timeslots",
	    port: 8282,
	    method: "POST",
	    headers: {
	        "Content-Type": "application/json",
	        "Authorisation" : "Bearer CyO2Zy28Xwon2upNRMeMXpf2Orka",
	        "Channel": "ECOM"
	    }
		
	}

	var request = http.get(options, function(response) {
	    response.setEncoding('utf8');
	    response.on('data', function(chunk) {

	        console.log(chunk);
	    });
	});
	
	request.on('error',function (e) {
		  console.log('problem with request:'+e.message);
		});
	
	var reqBody = {store:{storeId:"HarshStore",info:{openTime:"09:30",closeTime:"18:00"}},"consumer":{"address":{"postCode":"HA11JU"}},"items":{"readyAt":"2015-10-06T09:00:00Z","deliveryDate":"2015-10-06"}};
	request.write(reqBody);
	request.end();
}

function processTS(data) {
	alert(data);
}
function setHeader(xhr) {
	xhr.setRequestHeader('Access-Control-Allow-Origin', 'http://sbapi.onthedot.com');
	xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
	xhr.setRequestHeader('Access-Control-Allow-Methods', 'DELETE, HEAD, GET, OPTIONS, POST, PUT');
	xhr.setRequestHeader('Access-Control-Allow-Headers', 'Access-Control-Allow-Origin,Content-Type, Content-Range, Content-Disposition, Content-Description');
}