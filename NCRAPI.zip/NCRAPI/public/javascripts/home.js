/**
 * New node file
 */
$(function(){
        $('#DOJ').datepicker({dateFormat: 'yymmdd'});
});

var liveURL = 'http://api.railwayapi.com/live/train/';
var liveURL2 = '/doj/';
var liveURL3 = '/apikey/dfyoo6077/';

//Url should be of type - http://api.railwayapi.com/live/train/<train number>/doj/<yyyymmdd>/apikey/<apikey>/
function getStations() {
	var doj = $('#DOJ').val();
	var trainNo = $('#trainNo').val();
	var url = liveURL + trainNo + liveURL2 + doj +  liveURL3;
	//alert('calling URL:' + url);
	$.ajax({
        url: url,
        type: 'GET',
        dataType: 'json',
        success: processResp,
        error: function() { alert('boo!'); }
        
      });
	//alert('done');
}

function processResp(data) { 
	var stHTML = "<select>";
	var stations = data.route;
	for(var x in stations) {
		var station = stations[x];
		stHTML += '<option value=\'';
		stHTML += station.station_.code;
		stHTML += '\' time=\'';
		stHTML += station.scharr;
		stHTML += '\'>'
		stHTML += station.station_.name;
		stHTML += '</option>'
	}
	stHTML += '</select>';
	$('#stations').empty();
	$('#stations').append(stHTML);
}

